﻿# NeuroTeacher Bot 🤖

AI-преподаватель с Gemini Flash 2.0 для Telegram.

## 🚀 Быстрый старт

1. Клонируйте репозиторий
2. Установите зависимости: pip install -r requirements.txt
3. Создайте .env файл (см. .env.example)
4. Запустите: python app.py

## 🌐 Деплой на Render

Автоматический деплой из main ветки.
